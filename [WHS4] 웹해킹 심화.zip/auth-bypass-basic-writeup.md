# auth-bypass-basic (arang_bank) 라이트업

- 대상: `whs1-ctf2-authbypass-chall` / `auth-bypass-basic`
- 버그클래스: Business Logic Flaw (자기이체를 이용한 잔액 뻥튀기, TOCTOU성 잔액 계산 오류)
- 포트: 9001

## 취약점 분석

`app/app.py`의 `/transfer` (POST) 핸들러:

```python
info = getmyinfo(flask.session["login_info"]["userseq"])
from_address = info["acctno"]
to_address = flask.request.form["to_address"]
amount = int(flask.request.form["amount"])

nowamount = int(info["balance"])          # 내 잔액 (이체 전 값, 읽기 1)
...
query_result = db_select("select balance from users where acctno=%s", (to_address,))
toamount = int(query_result[0]["balance"])  # 받는 계좌 잔액 (이체 전 값, 읽기 2)
...
# sub money
db_update("update users set balance=%s where acctno=%s", (nowamount-amount, from_address))
# add money
db_update("update users set balance=%s where acctno=%s", (toamount+amount, to_address))
```

`to_address`에 제한이 없어 **본인 계좌로도 이체가 가능**하다. `from_address == to_address`인 경우:

- `nowamount`와 `toamount`는 실제로는 **같은 계좌의 같은 값**이지만, 이체가 실행되기 전에 각각 따로 읽어둔 스냅샷이다.
- 1차 UPDATE로 `nowamount-amount`가 DB에 기록된다.
- 곧바로 2차 UPDATE가 `toamount+amount` (= 이체 전 원래 잔액 + amount)로 **덮어써버려서**, 1차 UPDATE의 차감 효과가 사라진다.
- 최종 잔액 = `원래잔액 + amount`. 즉 자기 자신에게 전액을 이체할 때마다 **잔액이 매번 2배**가 된다.

`/getflag`는 로그인한 계정의 잔액이 10억을 초과하면 flag를 반환한다(관리자 계정일 필요 없음):

```python
@app.route("/getflag")
def getflag():
    if getmyinfo(flask.session["login_info"]["userseq"])["balance"] > 1000000000:
        return FLAG
```

## 익스플로잇

1. 아무 계정이나 회원가입(`/register`, 초기 잔액 10,000)
2. 로그인 후 `/transfer` 페이지에서 내 계좌번호(acctno) 확인
3. 이체 폼에서 `to_address` = 본인 계좌번호, `amount` = 현재 잔액 전액으로 반복 이체
4. 매 이체마다 잔액이 2배 (10,000 → 20,000 → 40,000 → ... ), 약 17회 반복하면 10억 초과
5. `/getflag` 접속 → flag 확인

## 진행 절차

1. `cd auth-bypass-basic && docker-compose up -d`
2. `http://localhost:9001/register` 에서 회원가입 → 로그인
3. `/transfer`에서 내 계좌번호로 자기 자신에게 전액 이체를 약 17회 반복
4. `http://localhost:9001/getflag` 접속 → flag 확인

## 플래그

```
flag{5aa1bb182e9da650c9bb}
```

## 대응방안

- 잔액 증감은 절대값 SET이 아니라 원자적 증감 연산(`UPDATE users SET balance = balance - %s WHERE acctno=%s`)으로 처리해 TOCTOU(스냅샷 이후 값 불일치) 문제를 제거
- 송금 시 `from_address == to_address`(자기 자신에게 이체)를 명시적으로 차단
- 트랜잭션(DB 트랜잭션 + 행 잠금 `SELECT ... FOR UPDATE`)으로 잔액 조회~갱신을 하나의 원자적 단위로 묶어 동시성/재계산 문제 방지
