# [auth] 2차인증(2FA) 검증 우회 라이트업

- 대상: `arang-edu-challs-collection` / `challenges/auth/2fa-bypass`
- 카테고리: auth
- 버그클래스: Improper Verification (2FA bypass)
- 포트: 9302

## 취약점 분석

`challenges/auth/2fa-bypass/app.py`:

```python
@app.route("/login", methods=["GET", "POST"])
def login():
    ...
    if USERS.get(request.form.get("u")) == request.form.get("p"):
        session["stage"] = "otp"; session["u"] = request.form["u"]   # 1단계 통과
        return redirect("/otp")
    ...

@app.route("/otp", methods=["GET", "POST"])
def otp():
    ...
    if request.form.get("otp") == OTP:
        session["stage"] = "done"; return "2FA 완료. <a href=/secret>secret</a>"
    ...

@app.route("/secret")
def secret():
    # ── 결함: OTP 완료('done')가 아니라 비번단계('otp')만 확인 ──
    if session.get("stage") in ("otp", "done"):
        return "기밀: " + FLAG
    return redirect("/login")
```

로그인 성공 시 `session["stage"]`가 `"otp"`로 설정되고, OTP까지 맞으면 `"done"`으로 바뀐다. 그런데 보호 자원인 `/secret`은 `stage`가 `"otp"` **또는** `"done"`이면 통과시킨다 — 즉 비밀번호 단계만 통과해도(OTP를 아예 풀지 않아도) 최종 자원에 접근 가능한 논리 결함이다. OTP 자체는 서버만 알고 있어 사용자에게 노출되지 않으므로, 정상 경로로는 절대 못 뚫지만 이 검증 결함으로 OTP 단계를 완전히 건너뛸 수 있다.

## 익스플로잇

1. `guest`/`guest`로 `/login` 통과 → `session["stage"] = "otp"`로 설정되고 `/otp`로 리다이렉트됨
2. OTP를 입력하지 않고, 그대로 `/secret`으로 직접 접근

```
http://localhost:9302/secret
```

`session["stage"]`가 이미 `"otp"`이므로 조건을 통과해 flag가 그대로 출력된다.

## 진행 절차

1. `docker compose up -d --build 2fa-bypass`
2. `http://localhost:9302/login` 에서 guest/guest 로그인
3. OTP 화면이 떠도 입력하지 말고 `http://localhost:9302/secret` 으로 바로 접속
4. 응답에서 flag 확인

## 플래그

```
flag{63f9cdc842dbcd41bad1}
```

## 대응방안

- 다단계 인증(MFA)의 각 단계는 반드시 명시적이고 구분된 상태 값으로 관리하고, 보호 자원은 "모든 단계 완료" 상태(`"done"`)만을 엄격히 확인해야 한다 (`in ("otp","done")`처럼 중간 단계까지 허용하는 실수를 피할 것)
- 인증 상태 머신을 도입할 때는 각 보호 엔드포인트마다 요구되는 최소 상태를 명확히 정의하고 테스트로 검증
- 세션에 저장하는 인증 진행 상태 이름을 모호하지 않게(예: `otp_verified: bool`) 설계해 실수를 줄일 것
