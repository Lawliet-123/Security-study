# [auth] IDOR — 계좌 잔액 조회 라이트업

- 대상: `arang-edu-challs-collection` / `challenges/auth/idor-balance`
- 카테고리: auth
- 버그클래스: IDOR / BOLA (Broken Object Level Authorization)
- 포트: 9301

## 취약점 분석

`challenges/auth/idor-balance/app.py`:

```python
ACCTS = {
    "1001": {"owner": "guest", "balance": 12000, "memo": "내 입출금통장"},
    "1000": {"owner": "admin", "balance": 999999999, "memo": FLAG},  # 관리자 계좌 메모에 flag
}

@app.route("/balance")
def balance():
    if not session.get("u"):
        return redirect("/login")
    acct = request.args.get("acct", "")
    a = ACCTS.get(acct)
    if not a:
        return "없는 계좌"
    # ── IDOR: 세션 사용자와 계좌 소유자 일치 검증이 없음 ──
    return "계좌 %s · 잔액 %s · 메모: %s" % (acct, a["balance"], a["memo"])
```

로그인 여부만 확인할 뿐, 조회하려는 계좌(`acct`)의 소유자(`owner`)가 현재 로그인한 세션 사용자와 일치하는지 전혀 검증하지 않는다. 로그인만 되어 있으면 어떤 계좌 번호든 조회 가능한 전형적인 IDOR(Insecure Direct Object Reference)/BOLA 취약점이다.

## 익스플로잇

1. `guest`/`guest`로 로그인 (폼에 기본값으로 채워져 있음)
2. 잔액조회 요청의 `acct` 파라미터를 본인 계좌(`1001`) 대신 admin 계좌(`1000`)로 변경

```
http://localhost:9301/balance?acct=1000
```

응답에 admin 계좌의 잔액과 메모(=flag)가 그대로 노출된다.

## 진행 절차

1. `docker compose up -d --build idor-balance`
2. `http://localhost:9301` 접속 → guest/guest 로그인
3. `http://localhost:9301/balance?acct=1000` 접속
4. 응답에서 flag 확인

## 플래그

```
flag{13ad849d522152446a8d}
```

## 대응방안

- 리소스 조회/조작 시 항상 서버 측에서 "요청한 리소스의 소유자 == 현재 인증된 사용자"를 검증(객체 단위 인가, Object-Level Authorization)
- 추측 가능한 순차적 ID(1000, 1001 등) 대신 UUID 등 예측 불가능한 식별자 사용(근본 대책은 아니지만 방어 심층화에 도움)
- 민감한 리소스는 소유자 검증 로직을 프레임워크/미들웨어 레벨에서 일관되게 강제
